package com.example.demo.domaine;

public class Message {
  public String message;

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public Message() {
    super();
    // TODO Auto-generated constructor stub
  }

  public Message(String message) {
    super();
    this.message = message;
  }


}
