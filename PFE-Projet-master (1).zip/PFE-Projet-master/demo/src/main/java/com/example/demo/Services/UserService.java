package com.example.demo.Services;

import com.example.demo.Model.User;
import org.springframework.stereotype.Service;


public interface UserService {
  public void saveUser(User user) ;
}
