export class Fournisseur{
  id!:number;
  name!:string;

}
