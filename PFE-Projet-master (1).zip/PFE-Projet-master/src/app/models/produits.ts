export class Produit{
  ref!:number;
  consomAnnee!:string;
  prix!:string;
  observation!:string;
  designation!:string;

}
