export class Famille{
  id!:number;
  nom!:string;
  desc!:string;
}
