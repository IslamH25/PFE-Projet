export class Filiale{
  id!:number;
  name!:string;
  desc!:string;
  sect!:string;
}
