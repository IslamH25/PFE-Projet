export class Fabricant{
  id!:number;
  nom!:string;
  type!:string;
}
