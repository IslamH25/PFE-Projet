export class User {

  id!: number;
  username!: string;
  roles!: any[];
  password! : string;
  role !: string;
  jwt! : string;

}
