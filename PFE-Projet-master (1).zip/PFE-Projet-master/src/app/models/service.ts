export class Service{
  id!:number;
  nom!:string;
  designation!:string;
}
